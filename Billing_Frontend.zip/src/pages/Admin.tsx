import React from 'react'


const Admin: React.FC = () => {
    return (
        <div>
            <h3>Admin</h3>
            <p>Manage staff, permissions, expenses, suppliers, and backup / restore (needs backend).</p>
        </div>
    )
}
export default Admin
